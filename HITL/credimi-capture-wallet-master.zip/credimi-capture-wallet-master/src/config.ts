import { randomBytes } from "node:crypto";
import { X509Certificate as NodeX509Certificate } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { CredoWebCrypto, Kms, X509Certificate, X509KeyUsage } from "@credo-ts/core";
import { exportJWK, generateKeyPair } from "jose";
import { resolvedIssuerConfigurations } from "./configurations/registry.js";
import { issuerAppConfig } from "./configurations/resolve-urls.js";
import type { ResolvedIssuerConfiguration } from "./configurations/types.js";
import type { AppConfig, JsonRecord } from "./types.js";

export const VERIFIER_KEY_ID = "credimi-fake-verifier-key";
export const ACCESS_TOKEN_PRIVATE_JWK_FILE = "access-token-private-jwk.json";

export const DEFAULT_CONFIG: AppConfig = {
  issuer_base_url: "http://localhost:8080",
  listen_addr: ":8080",
  data_dir: "./data",
  credential_configuration_id: "urn:eu.europa.ec.eudi:pid:1",
  credential_format: "dc+sd-jwt",
  credential_scope: "urn:eu.europa.ec.eudi:pid:1",
  authorization_code_ttl_seconds: 300,
  par_request_uri_ttl_seconds: 90,
  access_token_ttl_seconds: 600,
  nonce_ttl_seconds: 300,
  permissive_capture: true,
  gui_enabled: true,
};

export const PORT_ENV_VAR = "PORT";
export const GUI_ENABLED_ENV_VAR = "GUI_ENABLED";

export interface InitOptions {
  issuer_base_url?: string;
  data_dir?: string;
  credential_configuration_id?: string;
  force?: boolean;
}

export function parseArgs(argv: string[]): Record<string, string | boolean> {
  const parsed: Record<string, string | boolean> = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) continue;
    const key = token.slice(2).replaceAll("-", "_");
    const next = argv[index + 1];
    if (!next || next.startsWith("--")) {
      parsed[key] = true;
      continue;
    }
    parsed[key] = next;
    index += 1;
  }
  return parsed;
}

export function normalizeBaseUrl(value: string): string {
  const trimmed = value.trim().replace(/\/+$/, "");
  const normalized = trimmed.includes("://")
    ? trimmed
    : `${defaultBaseUrlScheme(trimmed)}://${trimmed}`;
  try {
    new URL(normalized);
  } catch {
    throw new Error(`issuer_base_url must be an absolute URL or host, got '${value}'`);
  }
  return normalized;
}

function defaultBaseUrlScheme(value: string): "http" | "https" {
  const host = value.split("/")[0]?.toLowerCase() ?? "";
  if (
    host === "localhost" ||
    host.startsWith("localhost:") ||
    host.startsWith("127.") ||
    host.startsWith("0.0.0.0") ||
    host.startsWith("[::1]")
  ) {
    return "http";
  }
  return "https";
}

export function parseListenAddr(addr: string): { host?: string; port: number } {
  if (addr.startsWith(":")) return { port: Number.parseInt(addr.slice(1), 10) };
  const url = new URL(addr.includes("://") ? addr : `http://${addr}`);
  return { host: url.hostname, port: Number.parseInt(url.port || "8080", 10) };
}

export function resolveListenAddr(
  config: AppConfig,
  env: NodeJS.ProcessEnv = process.env,
): { host?: string; port: number } {
  const listenAddr = parseListenAddr(config.listen_addr);
  const rawPort = env[PORT_ENV_VAR]?.trim();
  if (!rawPort) return listenAddr;
  return { ...listenAddr, port: parsePortEnv(rawPort) };
}

function parsePortEnv(value: string): number {
  if (!/^\d+$/.test(value)) {
    throw new Error(`${PORT_ENV_VAR} must be an integer between 1 and 65535`);
  }
  const port = Number.parseInt(value, 10);
  if (port < 1 || port > 65535) {
    throw new Error(`${PORT_ENV_VAR} must be an integer between 1 and 65535`);
  }
  return port;
}

export function loadEnvFile(
  path = ".env",
  env: NodeJS.ProcessEnv = process.env,
): NodeJS.ProcessEnv {
  if (!existsSync(path)) return env;
  return { ...parseEnvText(readFileSync(path, "utf8")), ...env };
}

export function parseEnvText(text: string): Record<string, string> {
  const result: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const source = trimmed.startsWith("export ") ? trimmed.slice(7).trim() : trimmed;
    const separator = source.indexOf("=");
    if (separator < 1) continue;
    const key = source.slice(0, separator).trim();
    const rawValue = source.slice(separator + 1).trim();
    result[key] = rawValue.replace(/^(["'])(.*)\1$/, "$2");
  }
  return result;
}

export function resolveGuiEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  const raw = env[GUI_ENABLED_ENV_VAR]?.trim().toLowerCase();
  if (!raw) return DEFAULT_CONFIG.gui_enabled;
  if (["1", "true", "yes", "on"].includes(raw)) return true;
  if (["0", "false", "no", "off"].includes(raw)) return false;
  throw new Error(`${GUI_ENABLED_ENV_VAR} must be true or false`);
}

export function stringifyYaml(record: JsonRecord): string {
  return `${Object.entries(record)
    .map(([key, value]) => `${key}: ${JSON.stringify(value)}`)
    .join("\n")}\n`;
}

export function parseYamlConfig(text: string): Partial<AppConfig> {
  const result: JsonRecord = {};
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf(":");
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    const raw = trimmed.slice(separator + 1).trim();
    if (raw === "true" || raw === "false") {
      result[key] = raw === "true";
      continue;
    }
    const numberValue = Number(raw);
    if (raw !== "" && Number.isFinite(numberValue)) {
      result[key] = numberValue;
      continue;
    }
    try {
      result[key] = JSON.parse(raw);
    } catch {
      result[key] = raw.replace(/^"|"$/g, "");
    }
  }
  return result as Partial<AppConfig>;
}

export function configPath(dataDir: string): string {
  return join(dataDir, "config.yaml");
}

export function jwksPath(dataDir: string): string {
  return join(dataDir, "jwks.json");
}

export function privateJwkPath(dataDir: string): string {
  return join(dataDir, "issuer-private-jwk.json");
}

export function issuerCertificatePath(dataDir: string): string {
  return join(dataDir, "issuer-certificate.pem");
}

export function issuerEncryptionPrivateJwkPath(dataDir: string): string {
  return join(dataDir, "issuer-encryption-private-jwk.json");
}

export function verifierPrivateJwkPath(dataDir: string): string {
  return join(dataDir, "verifier", "verifier-private-jwk.json");
}

export function verifierJwksPath(dataDir: string): string {
  return join(dataDir, "verifier", "verifier-jwks.json");
}

export function verifierCertificatePath(dataDir: string): string {
  return join(dataDir, "verifier", "verifier-certificate.pem");
}

export function accessTokenPrivateJwkPath(materialDirectory: string): string {
  return join(materialDirectory, ACCESS_TOKEN_PRIVATE_JWK_FILE);
}

export function loadConfig(dataDir = DEFAULT_CONFIG.data_dir): AppConfig {
  const env = loadEnvFile();
  const path = configPath(dataDir);
  const fileConfig = existsSync(path) ? parseYamlConfig(readFileSync(path, "utf8")) : {};
  return {
    ...DEFAULT_CONFIG,
    ...fileConfig,
    issuer_base_url: normalizeBaseUrl(fileConfig.issuer_base_url ?? DEFAULT_CONFIG.issuer_base_url),
    data_dir: fileConfig.data_dir ?? dataDir,
    gui_enabled: resolveGuiEnabled(env),
  };
}

export async function initIssuer(options: InitOptions): Promise<AppConfig> {
  const dataDir = options.data_dir ?? DEFAULT_CONFIG.data_dir;
  const force = options.force === true;
  const config: AppConfig = {
    ...DEFAULT_CONFIG,
    issuer_base_url: normalizeBaseUrl(options.issuer_base_url ?? DEFAULT_CONFIG.issuer_base_url),
    data_dir: dataDir,
    credential_configuration_id:
      options.credential_configuration_id ?? DEFAULT_CONFIG.credential_configuration_id,
    credential_scope: options.credential_configuration_id ?? DEFAULT_CONFIG.credential_scope,
  };

  mkdirSync(dataDir, { recursive: true });
  const cfgPath = configPath(dataDir);

  if (force || !existsSync(cfgPath)) {
    writeFileSync(cfgPath, stringifyYaml(config as unknown as JsonRecord), { mode: 0o600 });
  }

  const loadedConfig = loadConfig(dataDir);
  for (const issuer of resolvedIssuerConfigurations(loadedConfig)) {
    await ensureIssuerMaterial(loadedConfig, issuer, force);
  }
  const verifierSecretPath = verifierPrivateJwkPath(dataDir);
  const verifierPublicPath = verifierJwksPath(dataDir);
  const verifierCertPath = verifierCertificatePath(dataDir);
  mkdirSync(dirname(verifierSecretPath), { recursive: true });
  await ensureVerifierMaterial({
    config: loadedConfig,
    force,
    secretPath: verifierSecretPath,
    publicPath: verifierPublicPath,
    certificatePath: verifierCertPath,
  });
  validateIssuerMaterial(loadedConfig);

  return loadedConfig;
}

export function validateIssuerMaterial(config: AppConfig): void {
  const publicKeyOwners = new Map<string, string>();

  for (const issuer of resolvedIssuerConfigurations(config)) {
    const material = issuerAppConfig(config, issuer);
    const paths = {
      signing: privateJwkPath(issuer.materialDirectory),
      encryption: issuerEncryptionPrivateJwkPath(issuer.materialDirectory),
      accessToken: accessTokenPrivateJwkPath(issuer.materialDirectory),
      certificate: issuerCertificatePath(issuer.materialDirectory),
      jwks: jwksPath(issuer.materialDirectory),
    };
    for (const [role, path] of Object.entries(paths)) {
      if (!existsSync(path)) {
        throw new Error(`Issuer '${issuer.id}' is missing ${role} material at '${path}'`);
      }
    }

    const signingPrivateJwk = readJwk(paths.signing, issuer.id, "signing");
    const encryptionPrivateJwk = readJwk(paths.encryption, issuer.id, "encryption");
    const accessTokenPrivateJwk = readJwk(paths.accessToken, issuer.id, "access-token");
    const signingKeyId = requiredJwkKeyId(signingPrivateJwk, `Issuer '${issuer.id}' signing key`);
    const certificatePem = readFileSync(paths.certificate, "utf8");
    const certificate = X509Certificate.fromEncodedCertificate(certificatePem);
    if (!Kms.PublicJwk.fromUnknown(toPublicJwk(signingPrivateJwk)).equals(certificate.publicJwk)) {
      throw new Error(`Issuer '${issuer.id}' certificate does not match its signing key`);
    }
    const nodeCertificate = new NodeX509Certificate(certificatePem);
    validateIssuerCertificateSubjectAlternativeName(
      nodeCertificate.subjectAltName,
      issuer.issuerIdentifier,
      issuer.id,
    );

    const publishedJwks = loadIssuerJwks(material);
    const signingPublicJwk = Kms.PublicJwk.fromUnknown(toPublicJwk(signingPrivateJwk));
    const publishedSigningJwk = publishedJwks.keys.find((jwk) => {
      try {
        return Kms.PublicJwk.fromUnknown(jwk).equals(signingPublicJwk);
      } catch {
        return false;
      }
    });
    if (!publishedSigningJwk) {
      throw new Error(`Issuer '${issuer.id}' JWKS does not publish its signing key`);
    }
    if (publishedSigningJwk.kid !== signingKeyId) {
      throw new Error(`Issuer '${issuer.id}' JWKS kid does not match its private signing JWK kid`);
    }

    registerUniquePublicKey(publicKeyOwners, issuer.id, "signing", signingPrivateJwk);
    registerUniquePublicKey(publicKeyOwners, issuer.id, "encryption", encryptionPrivateJwk);
    registerUniquePublicKey(publicKeyOwners, issuer.id, "access-token", accessTokenPrivateJwk);
  }
}

export function validateIssuerCertificateSubjectAlternativeName(
  subjectAlternativeName: string | undefined,
  issuerIdentifier: string,
  issuerId: string,
): void {
  const names = subjectAlternativeName?.split(", ") ?? [];
  if (!names.includes(`URI:${issuerIdentifier}`)) {
    throw new Error(`Issuer '${issuerId}' certificate is missing URI SAN '${issuerIdentifier}'`);
  }
}

function readJwk(path: string, issuerId: string, role: string): JsonRecord {
  try {
    return JSON.parse(readFileSync(path, "utf8")) as JsonRecord;
  } catch (error) {
    throw new Error(
      `Issuer '${issuerId}' has invalid ${role} JWK material: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
  }
}

function registerUniquePublicKey(
  owners: Map<string, string>,
  issuerId: string,
  role: string,
  privateJwk: JsonRecord,
): void {
  const publicJwk = Kms.PublicJwk.fromUnknown(toPublicJwk(privateJwk));
  const identity = publicJwk.fingerprint;
  const owner = owners.get(identity);
  if (owner) {
    throw new Error(`Issuer key reuse detected between '${owner}' and '${issuerId}:${role}'`);
  }
  owners.set(identity, `${issuerId}:${role}`);
}

async function ensureIssuerMaterial(
  rootConfig: AppConfig,
  issuer: ResolvedIssuerConfiguration,
  force: boolean,
): Promise<void> {
  const materialDirectory = issuer.materialDirectory;
  const publicPath = jwksPath(materialDirectory);
  const secretPath = privateJwkPath(materialDirectory);
  const certificatePath = issuerCertificatePath(materialDirectory);
  const encryptionSecretPath = issuerEncryptionPrivateJwkPath(materialDirectory);
  const accessTokenSecretPath = accessTokenPrivateJwkPath(materialDirectory);

  mkdirSync(materialDirectory, { recursive: true });
  if (force || !existsSync(secretPath)) {
    await writeGeneratedJwkPair(secretPath, publicPath, issuer.issuerKeyId);
  }
  if (force || !existsSync(certificatePath)) {
    await writeIssuerCertificate(
      certificatePath,
      issuerAppConfig(rootConfig, issuer),
      issuer.issuerKeyId,
    );
  }
  writePublicJwksFromPrivate(publicPath, secretPath);
  writeIssuerJwksCertificate(publicPath, certificatePath);
  await ensureIssuerEncryptionMaterial({
    force,
    secretPath: encryptionSecretPath,
    keyId: issuer.issuerEncryptionKeyId,
  });
  if (force || !existsSync(accessTokenSecretPath)) {
    await writeGeneratedPrivateJwk(accessTokenSecretPath, issuer.accessTokenKeyId);
  }
}

export function loadIssuerJwks(config: AppConfig): { keys: JsonRecord[] } {
  const path = jwksPath(config.data_dir);
  if (!existsSync(path)) return { keys: [] };
  const jwks = JSON.parse(readFileSync(path, "utf8")) as { keys: JsonRecord[] };
  const certificatePath = issuerCertificatePath(config.data_dir);
  if (!existsSync(certificatePath)) return jwks;
  return withIssuerCertificate(jwks, readFileSync(certificatePath, "utf8"));
}

export function loadIssuerCertificate(config: AppConfig): X509Certificate {
  return X509Certificate.fromEncodedCertificate(
    readFileSync(issuerCertificatePath(config.data_dir), "utf8"),
  );
}

export function loadIssuerPublicJwk(config: AppConfig): JsonRecord {
  const privateJwk = JSON.parse(
    readFileSync(privateJwkPath(config.data_dir), "utf8"),
  ) as JsonRecord;
  return toPublicJwk(privateJwk);
}

export function issuerSigningKeyId(config: AppConfig): string {
  const privateJwk = JSON.parse(
    readFileSync(privateJwkPath(config.data_dir), "utf8"),
  ) as JsonRecord;
  return requiredJwkKeyId(privateJwk, `Issuer signing key in '${config.data_dir}'`);
}

export function loadIssuerEncryptionPrivateJwk(config: AppConfig): JsonRecord | null {
  const path = issuerEncryptionPrivateJwkPath(config.data_dir);
  if (!existsSync(path)) return null;
  return JSON.parse(readFileSync(path, "utf8")) as JsonRecord;
}

export function loadIssuerEncryptionPublicJwk(config: AppConfig): JsonRecord | null {
  const privateJwk = loadIssuerEncryptionPrivateJwk(config);
  return privateJwk ? toPublicJwk(privateJwk) : null;
}

export function createIssuerSigningContext(config: AppConfig): object {
  const privateJwk = JSON.parse(
    readFileSync(privateJwkPath(config.data_dir), "utf8"),
  ) as JsonRecord;
  return {
    ...createSigningContext(privateJwk, issuerSigningKeyId(config)),
    config: {
      allowInsecureHttpUrls: true,
      agentDependencies: { fetch: globalThis.fetch },
    },
  };
}

async function ensureIssuerEncryptionMaterial({
  force,
  secretPath,
  keyId,
}: {
  force: boolean;
  secretPath: string;
  keyId: string;
}): Promise<void> {
  if (!force && existsSync(secretPath)) return;
  const { privateKey } = await generateKeyPair("ECDH-ES", { extractable: true });
  const privateJwk = await exportJWK(privateKey);
  const common = {
    alg: "ECDH-ES",
    use: "enc",
    kid: keyId,
  };
  writeJson(secretPath, { ...privateJwk, ...common });
}

async function writeIssuerCertificate(
  path: string,
  config: AppConfig,
  keyId: string,
): Promise<void> {
  await writeCertificate({
    path,
    privateJwkPath: privateJwkPath(config.data_dir),
    keyId,
    organizationalUnit: "Credimi Fake Issuer",
    config,
  });
}

async function ensureVerifierMaterial({
  config,
  force,
  secretPath,
  publicPath,
  certificatePath,
}: {
  config: AppConfig;
  force: boolean;
  secretPath: string;
  publicPath: string;
  certificatePath: string;
}): Promise<void> {
  if (force || !existsSync(secretPath)) {
    await writeGeneratedJwkPair(secretPath, publicPath, VERIFIER_KEY_ID);
  }
  if (force || !existsSync(certificatePath)) {
    await writeCertificate({
      path: certificatePath,
      privateJwkPath: secretPath,
      keyId: VERIFIER_KEY_ID,
      organizationalUnit: "Credimi Fake Verifier",
      config,
    });
  }
  writePublicJwksFromPrivate(publicPath, secretPath, VERIFIER_KEY_ID);
  writeIssuerJwksCertificate(publicPath, certificatePath);
}

async function writeGeneratedJwkPair(
  secretPath: string,
  publicPath: string,
  keyId: string,
): Promise<void> {
  const { publicKey, privateKey } = await generateKeyPair("ES256", { extractable: true });
  const publicJwk = await exportJWK(publicKey);
  const privateJwk = await exportJWK(privateKey);
  publicJwk.alg = "ES256";
  publicJwk.use = "sig";
  publicJwk.kid = keyId;
  privateJwk.alg = "ES256";
  privateJwk.use = "sig";
  privateJwk.kid = keyId;
  writeJson(publicPath, { keys: [publicJwk] });
  writeJson(secretPath, privateJwk);
}

async function writeGeneratedPrivateJwk(secretPath: string, keyId: string): Promise<void> {
  const { privateKey } = await generateKeyPair("ES256", { extractable: true });
  const privateJwk = await exportJWK(privateKey);
  writeJson(secretPath, {
    ...privateJwk,
    alg: "ES256",
    use: "sig",
    kid: keyId,
  });
}

async function writeCertificate({
  path,
  privateJwkPath: keyPath,
  keyId,
  organizationalUnit,
  config,
}: {
  path: string;
  privateJwkPath: string;
  keyId: string;
  organizationalUnit: string;
  config: AppConfig;
}): Promise<void> {
  const privateJwk = JSON.parse(readFileSync(keyPath, "utf8")) as JsonRecord;
  const publicJwk = Kms.PublicJwk.fromUnknown(toPublicJwk(privateJwk));
  publicJwk.keyId = keyId;
  const certificate = await X509Certificate.create(
    {
      authorityKey: publicJwk,
      issuer: {
        countryName: "IT",
        commonName: new URL(config.issuer_base_url).hostname,
        organizationalUnit,
      },
      validity: {
        notBefore: new Date("2024-01-01T00:00:00Z"),
        notAfter: new Date("2034-01-01T00:00:00Z"),
      },
      extensions: {
        subjectKeyIdentifier: { include: true },
        authorityKeyIdentifier: { include: true },
        keyUsage: { usages: [X509KeyUsage.DigitalSignature] },
        subjectAlternativeName: {
          name: [
            { type: "url", value: config.issuer_base_url },
            { type: "dns", value: new URL(config.issuer_base_url).hostname },
          ],
        },
        basicConstraints: { ca: false },
      },
    },
    new CredoWebCrypto(createSigningContext(privateJwk, keyId) as never),
  );
  certificate.keyId = keyId;
  writeFileSync(path, certificate.toString("pem"), { mode: 0o600 });
}

function toPublicJwk(privateJwk: JsonRecord): JsonRecord {
  const { d: _d, ...publicJwk } = privateJwk;
  return publicJwk;
}

function createSigningContext(privateJwk: JsonRecord, keyId: string): object {
  const publicJwk = toPublicJwk(privateJwk);
  const kms = {
    randomBytes: ({ length }: { length: number }) => randomBytes(length),
    getPublicKey: async ({ keyId: requestedKeyId }: { keyId: string }) => {
      if (requestedKeyId !== keyId) throw new Error(`Unknown key id '${requestedKeyId}'`);
      return publicJwk;
    },
    sign: async ({ keyId: requestedKeyId, data }: { keyId: string; data: Uint8Array }) => {
      if (requestedKeyId !== keyId) throw new Error(`Unknown key id '${requestedKeyId}'`);
      const { createPrivateKey, sign } = await import("node:crypto");
      return {
        signature: sign("sha256", data, {
          key: createPrivateKey({ key: privateJwk as never, format: "jwk" }),
          dsaEncoding: "ieee-p1363",
        }),
      };
    },
  };
  const resolve = (token: unknown) => {
    if (token === Kms.KeyManagementApi) return kms;
    throw new Error("Unsupported Credo dependency requested while creating issuer certificate");
  };

  return { resolve, dependencyManager: { resolve } };
}

function writePublicJwksFromPrivate(
  publicPath: string,
  secretPath: string,
  keyIdOverride?: string,
): void {
  const privateJwk = JSON.parse(readFileSync(secretPath, "utf8")) as JsonRecord;
  const publicJwk = toPublicJwk(privateJwk);
  publicJwk.alg = "ES256";
  publicJwk.use = "sig";
  publicJwk.kid = keyIdOverride ?? requiredJwkKeyId(privateJwk, `Private JWK '${secretPath}'`);
  writeJson(publicPath, { keys: [publicJwk] });
}

function requiredJwkKeyId(jwk: JsonRecord, description: string): string {
  if (typeof jwk.kid !== "string" || jwk.kid.length === 0) {
    throw new Error(`${description} is missing a kid`);
  }
  return jwk.kid;
}

function writeIssuerJwksCertificate(jwksFilePath: string, certificatePath: string): void {
  const jwks = JSON.parse(readFileSync(jwksFilePath, "utf8")) as { keys: JsonRecord[] };
  writeJson(jwksFilePath, withIssuerCertificate(jwks, readFileSync(certificatePath, "utf8")));
}

function withIssuerCertificate(
  jwks: { keys: JsonRecord[] },
  certificatePem: string,
): { keys: JsonRecord[] } {
  const certificate = pemToBase64Der(certificatePem);
  return {
    keys: jwks.keys.map((key) => (key.x5c === undefined ? { ...key, x5c: [certificate] } : key)),
  };
}

function pemToBase64Der(certificatePem: string): string {
  return certificatePem
    .replace(/-----BEGIN CERTIFICATE-----/g, "")
    .replace(/-----END CERTIFICATE-----/g, "")
    .replace(/\s+/g, "");
}

function writeJson(path: string, value: unknown): void {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
}
